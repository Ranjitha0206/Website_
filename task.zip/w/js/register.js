const form = document.querySelector("form"),
  firstnameField = form.querySelector(".firstname-field"),
  firstName = firstnameField.querySelector(".firstName");
  lastnamefield = form.querySelector(".lastname-field"),
  lastName = lastnamefield.querySelector(".lastName");
  emailField = form.querySelector(".email-field"),
  emailInput = emailField.querySelector(".email");
  contactField = form.querySelector(".contact-field"),
  contact = contactField.querySelector(".contact");
  zipField = form.querySelector(".zip-field"),
  zip = zipField.querySelector(".zip");
  


  function checkfirstName(){
    const fisrstnameIncludes =  /^[A-Za-z]+$/ ;
    if (!firstName.value.match(fisrstnameIncludes)){
        alert("Enter valid First Name");
        return firstnameField.classList.add("invalid");
    }
    return firstnameField.classList.remove("invalid");
  }
 
  function checklastName(){
    const lastnameIncludes =  /^[A-Za-z]+$/ ;
    if (!lastName.value.match(lastnameIncludes)){
        alert("Enter valid Last Name");
        return lastnamefield.classList.add("invalid");
    }
    return lastnamefield.classList.remove("invalid");
  }


// Email Validtion
function checkEmail() {
  const emaiPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!emailInput.value.match(emaiPattern)) {
    alert("Enter valid email address")
    return emailField.classList.add("invalid"); 
  }
  emailField.classList.remove("invalid"); 
}

function checkcontact() {
    const contactNumber = /^[0-9]{10}$/;
    if (!contact.value.match(contactNumber)) {
        alert("Invalid contact number");
      return contactField.classList.add("invalid"); 
    }
    contactField.classList.remove("invalid"); 
  }

  function checkzip() {
    const zipcode= /^[0-9]{4}$/;
    if (!zip.value.match(zipcode)) {
        alert("Invalid ZipCode");
      return zipField.classList.add("invalid"); //adding invalid class if email value do not mathced with email pattern
    }
    zipField.classList.remove("invalid"); //removing invalid class if email value matched with emaiPattern
  }


// Calling Funtion on Form Sumbit
form.addEventListener("submit", (e) => {
  e.preventDefault(); //preventing form submitting
  checkfirstName();
  checklastName();
  checkEmail();
  checkcontact();
  checkzip();
  

  //calling function on key up
//   firstName.addEventListener("submit", checkfirstName);
//    lastName.addEventListener("submit", checklastName);
//  emailInput.addEventListener("submit", checkEmail);
// contact.addEventListener("submit", checkcontact);
//   zip.addEventListener("submit", checkzip);
  
  

//   if(
//     firstName.value ==='' || lastName.value ==='' || emailInput.value==='' || contact.value ==='' || zip.value===''){
//         alert("Enter all the required details");
//     }
  

   if (
    !firstnameField.classList.contains("invalid")&&
    !lastnamefield.classList.contains("invalid")&&
    !emailField.classList.contains("invalid") &&
    !contactField.classList.contains("invalid") &&
    !zipField.classList.contains("invalid")
  ) {
    location.href = form.getAttribute("action");
  }
});


// if(
//     zip.value ===''){
//         alert("Enter all the required details");
//     }
//     else if (!zipField.classList.contains("invalid"))
//     {
//         location.href = form.getAttribute("action");
  
//     }
// });


