let shopItemsData = [
    {
            id: "ioytrhndce",
            name: "Parle-G",
            price: 20,
            desc: "Parle-G Biscuits",
            img: "images/Parle-G.jpg",
          },
        
          {
            id: "ioytrhndcf",
            name: "Oreo",
            price: 10,
            desc: "Oreo Biscuits",
            img: "images/oreo.jpg",
          },
        
          {
            id: "ioytrhndcg",
            name: "Dream Cream",
            price: 5,
            desc: "Dream Cream Biscuits",
            img: "images/tasty-and-crispy-dream-cream-chocolate-cream-biscuits-packaging-type-packet-225.jpg",
          }
        
        
          
        ];