// let shopItemsData = [
//   {
//     id: "jfhgbvnscs",
//     name: "Samsung",
//     price: 35000,
//     desc: "Samsung Galaxy 128GB storage",
//     img: "samsung.jpg",
//   },
//   {
//     id: "ioytrhndcv",
//     name: "iPhone",
//     price: 60000,
//     desc: "iPhone 12 63GB storage",
//     img: "iphone.jpg",
//   },
//   {
//     id: "wuefbncxbsn",
//     name: "OnePlus",
//     price: 45000,
//     desc: "OnePlus 128GB storage",
//     img: "oneplus.jpg",
//   },

  

//   {
//     id: "ioytrhndcc",
//     name: "Macbook",
//     price: 105000,
//     desc: "Macbook",
//     img: "macbook.jpg",
//   },
   
//   {
//     id: "ioytrhndcd",
//     name: "Acer",
//     price: 65000,
//     desc: "Acer Laptop",
//     img: "acer.png",
//   },

//   {
//     id: "ioytrhndce",
//     name: "Dell",
//     price: 70000,
//     desc: "Dell Laptop",
//     img: "dell.jpg",
//   },


//   {
//     id: "jfhgbvnsca",
//     name: "Hoodie",
//     price: 1000,
//     desc: "Hoodie",
//     img: "hoodie.jpg",
//   },
//   {
//     id: "ioytrhndcb",
//     name: "Jacket",
//     price: 2500,
//     desc: "Denim Jacket",
//     img: "jacket.jpg",
//   },



//   {
//     id: "ioytrhndce",
//     name: "Parle-G",
//     price: 20,
//     desc: "Parle-G Biscuits",
//     img: "Parle-G.jpg",
//   },

//   {
//     id: "ioytrhndcf",
//     name: "Oreo",
//     price: 10,
//     desc: "Oreo Biscuits",
//     img: "oreo.jpg",
//   },

//   {
//     id: "ioytrhndcg",
//     name: "Dream Cream",
//     price: 5,
//     desc: "Dream Cream Biscuits",
//     img: "tasty-and-crispy-dream-cream-chocolate-cream-biscuits-packaging-type-packet-225.jpg",
//   }


  
// ];



let shopItemsData = [
  {
        id: "ioytrhndcc",
        name: "Macbook",
        price: 105000,
        desc: "Macbook",
        img: "images/macbook.jpg",
      },
       
      {
        id: "ioytrhndcd",
        name: "Acer",
        price: 65000,
        desc: "Acer Laptop",
        img: "images/acer.png",
      },
    
      {
        id: "ioytrhndce",
        name: "Dell",
        price: 70000,
        desc: "Dell Laptop",
        img: "images/dell.jpg",
      }
    ]
    
    