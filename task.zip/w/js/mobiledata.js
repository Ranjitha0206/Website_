let shopItemsData = [
    {
       id: "jfhgbvnscs",
       name: "Samsung",
       price: 35000,
       desc: "Samsung 128GB storage",
       img: "images/sam.jpg",
    },
    {
      id: "ioytrhndcv",
      name: "iPhone",
      price: 60000,
      desc: "iPhone 12 63GB storage",
      img: "images/iphone.jpg",
    },
    {
      id: "wuefbncxbsn",
      name: "OnePlus",
      price: 45000,
      desc: "OnePlus 128GB storage",
      img: "images/oneplus.jpg",
    }
  
  ]