let shopItemsData = [
    {
      id: "jfhgbvnsca",
      name: "Hoodie",
      price: 1000,
      desc: "Hoodie",
      img: "images/hoodie.jpg",
    },
    {
      id: "ioytrhndcb",
      name: "Jacket",
      price: 2500,
      desc: "Denim Jacket",
      img: "images/jacket.jpg",
    }
    
    
  ];
  